/*
Todo:

Positioning of numbers - wie berechne ich jeweils den Minimumwert der "vergleich" Zahlen. Davon
möchte ich die Position berechnen.
Oder: wie mache ich ein Hintergrund-Kastl?

style text (bold? biger?)
Umlaute
Komma statt Punkt

more space between year-labeling and bars
positioning buttons & svg

Button nach oben - so dass er sich nicht mit dem Mouseover überlagert.
style labels for verfahren  

button styling

calculate 0.6

copy code of first table to others (labels etc)

fix mousover-layover

DONE: correct size for orf screens (Ö1 und ORF.at)
ORF.at: 
max. 800 breit, 326 hoch (aber geht auch mehr)
http://orf.at/wahl/nr13/ergebnisse/#ergebnisse

Ö1:
max 779 breit
996 hoch (aber da geht auch)
http://oe1.orf.at/artikel/374311

Done:
fix the following: if "weitere wahlen" is clicked first, "Vergleich" does not lead to anything.
Maybe a backup in weitere()? or an automatic call on the button - 
reveal wird auch bei on.("click")button1 aufgerufen.

*/
function bla(){

	var margin = {top: 10, right: 10, bottom: 30, left: 80,},
		width = 720 - margin.left - margin.right;
		height = 150 - margin.top - margin.bottom;

  //ordinal scale for "verfahren"
  var y = d3.scale.ordinal()
    .rangeRoundBands([20, height]); //schalter f. abstand zw. Balken & Abstand zur Jahreszahl
    //.rangeRoundBands([0, height], 0.1, 0);

  //linear scale for "mandate"
  var x = d3.scale.linear()
    .range([0, 500]); //

  //to assign party colors. Could also be done with an ordinal scale
  var color = {"SPO":"#d41328", "OVP": "#060000", "FPO":"#2453a1", "Grune": "#84b414"};

  //tooltip - mainly for debugging
  var tip = d3.tip()
    .attr("class", "d3-tip")
    .offset([-5, 20])
    .html( function(d){return "<text>"+ d.name + ":"+ (d.x1-d.x0) +" Mandate"+ "</text>" });
  
  var button = d3.select('body')
    .append( 'button' )
    .text( 'Vergleich' )
    .attr("class","button");
  
  var button1 = d3.select("body")
    .append("button")
    .text("Weitere Wienwahlen")
    .attr("class", "button1")

    //add svg
  var svg = d3.select("body").append("svg")
    .attr("width", width  + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom )
    .append("g")
    .attr("transform", "translate(" + 82 + ","+ 38 + ")");

  svg.append("text")
    .text("2010")
    .style("fill", "black")
      .attr("x", 5)
      .attr("y", -13) //handle for distance between first bar and year
      .attr("class", "heading")
      //.attr("dy", "0.65em")
      //.attr("text-anchor", "start");

  //call tip
  svg.call(tip);

  //add the data
	d3.tsv("2010_neu.tsv", function(error, data){

    var partei = ( d3.keys( data[0]).filter( function(key){return key !== "verfahren"; } ) );

    data.forEach(function(d){
			x0 = 0;
      d.mandate = partei.map(function(name){ return {name: name, verfahren: d.verfahren, x0: x0, x1: x0 += +d[name]} });
		})

    //set domains
    y.domain(data.map(function(d){return d.verfahren; }) );
    x.domain([0, 100 ]); //100 Mandate


    //create goups for verfahren and position them
    var verfahren = svg.selectAll(".verfahren")
      .data(data)
      .enter()
      .append("g")
      .attr("class", "g")
      .attr("transform", function(d){ return "translate(0," +y(d.verfahren)+")" });

    //create group for rects
    verfahren.selectAll("rectgroup")
      .data(function(d){ return d.mandate; })
      .enter()
      .append("g")
      .attr("class", "rect")
      //set the x attribute to a fixed value according to party
      .attr("transform", function(d){
        switch(d.name){
          case "SPO":
            return "translate (" + x(d.x0) + ", 0)"
            break;
          case "OVP":
            return "translate (" + x(58) + ",0)"
            break;
          case "Grune":
            return "translate (" + x(80) + ",0)" 
            break;
          case "FPO":
            return "translate (" + x(99) + ",0)" 
        }
      })
      .append("rect")
      .classed('eins', function(d) { return d.verfahren === 'eins'; } )
      .classed('vergleich', function(d) { return d.verfahren !== 'eins' && d.verfahren !== 'stimmen'; } )
      .classed("stimmen", function(d){ return d.verfahren == "stimmen"; })
      .on("mouseover", tip.show)
      .on("mouseout", tip.hide)
      
      verfahren.selectAll(".rect")
      .append("text")
      //.text(function(d){ return (d.x1-d.x0); })
        .classed('eins', function(d) { return d.verfahren === 'eins'; } )
        .classed('vergleich', function(d) { return d.verfahren !== 'eins' && d.verfahren !== 'stimmen'; } )
        .classed("stimmen", function(d){ return d.verfahren == "stimmen"; })
      
    //create bars
    /*
    verfahren.selectAll(".rect")
      .data(function(d){ return d.mandate; })
      .enter()
      .append("rect")
      .classed('eins', function(d) { return d.verfahren === 'eins'; } )
      .classed('vergleich', function(d) { return d.verfahren !== 'eins'; } )
      .on("mouseover", tip.show)
      .on("mouseout", tip.hide)
    */

    function reveal( what ) {
      
      verfahren.selectAll('rect.' + what)
      .transition().duration(2500)
      //.each("start", console.log("start"))
      .each("end", function(d){ 
          verfahren.selectAll("text." + what)
            .text(function(d){ 
              if(d.verfahren == "stimmen"){
                return d.name + ": " + d3.round((d.x1-d.x0), 2) + " % ";
              }else{
                return (d.x1-d.x0);
              }
            })
            .style("fill", function(d){
                if(d.verfahren == "eins"){
                  return "white"
                }else{
                  return "black"
                }
            })
            .attr("x", function(d){ 
              if(d.verfahren == "stimmen"){
                x(d.x0);
              }else if (d.verfahren == "eins"){
                return (x(d.x1-d.x0)-17);
              }else{
                return (x(d.x1-d.x0)-17);
                //lege ein Array aller Mandate dieser Partei an
                //nimm den kleinsten Wert
                //berechne daraus das x
              }
            })
            .attr("y", function(d){
              if(d.verfahren == "stimmen"){
                return -7;
              }else{
                return -3;
              }
            });
      })

      //set the height according to "verfahren"
      .attr("height", function(d){
          if(d.verfahren == "eins"){
            //return y.rangeBand()/2 ;
            return 16;
          }else if(d.verfahren =="stimmen"){
            return 6;
          }else{
            return 2;
          }
      })
      .attr("width", function(d) { return x(d.x1)-x(d.x0); })
      .style("fill", function(d){ return color[d.name] })
      .style("fill-opacity", function(d){
          if(d.verfahren == "stimmen"){
            return "0.5";
          }else{
            return "1";
          }
            
        })
      .attr( "transform", function(d){ //move 1st bar to top, so space is evenly distributed
          if(d.verfahren == "eins"){
            return "translate(0," + -14 + ")";
          }else if(d.verfahren == "stimmen"){
            return "translate(0," + -4 + ")"; //move 2nd bar a bit mor to the top
          }
        })
    }
    
    reveal( 'eins' );
    reveal('stimmen');
    reveal('stimmen');

    button.on("click", function( ) {
      reveal( 'vergleich' );
    } );

      //add labels for verfahren
      verfahren.append("text")
      .text(function(d){
        switch(d.verfahren){
          case "stimmen":
            return "Stimmen"
            break;
          case "eins":
            return "Mandate"
            break;
          case "n":
            return "Ungewichtet (+0)"
            break;
          case "n5":
            return "ab 2020 (+0,5)"
            break;
          case "n75":
            return "2015 (+0,75)"
        }
      })
      .style("fill", "black")
      .attr("x", -5)
      .attr("dy", "0.1em")
      .attr("text-anchor", "end");

    //muss hier drinnen stehen, sonst funktioniert das select nicht. Wieso?
    d3.select(".button1").on("click", function(){
      reveal("vergleich"),
      weitere( "2005.tsv" ); //weiß die methode so, dass ich ein File übergebe? Ja. Hat funktioniert!!
      weitere( "2001.tsv" );
      weitere( "1996.tsv" );
    });

  });
  
}

bla();

//function to call other three charts
function weitere( file ){
  var margin = {top: 10, right: 10, bottom: 30, left: 80,},
    width = 700 - margin.left - margin.right;
    height = 150 - margin.top - margin.bottom;

  //ordinal scale for "verfahren"
  var y = d3.scale.ordinal()
    .rangeRoundBands([0, height], 0.3);

  //linear scale for "mandate"
  var x = d3.scale.linear()
    .range([0, 500]); //

  //to assign party colors. Could also be done with an ordinal scale
  var color = {"SPO":"#d41328", "OVP": "#060000", "FPO":"#2453a1", "Grune": "#84b414", "LIF": "#f8d323"};

  //tooltip - mainly for debugging
  var tip = d3.tip()
    .attr("class", "d3-tip")
    .offset([-10, 20])
    .html( function(d){return "<text>"+ d.name + ":"+ (d.x1-d.x0) +" Mandate"+ "</text>" });

    //add svg
  var svg = d3.select("body").append("svg")
    .attr("width", width  + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom )
    .append("g")
    .attr("transform", "translate(" + 40 + ","+ 20 + ")");

  //call tip
  svg.call(tip);

  svg.append("text")
    .text( function(d){
      switch(file){
        case "2005.tsv":
          return "2005"
          break;
        case "2001.tsv":
          return "2001"
          break;
        case "1996.tsv":
          return "1996"
      }

    } )
    .style("fill", "black")
      .attr("x", 5)
      .attr("class", "heading")

  //add the data
  d3.tsv( file, function(error, data){
    var partei = ( d3.keys( data[0]).filter( function(key){return key !== "verfahren"; } ) );

    data.forEach(function(d){
      x0 = 0;
      d.mandate = partei.map(function(name){ return {name: name, verfahren: d.verfahren, x0: x0, x1: x0 += +d[name]} });
    })

    //set domains
    y.domain(data.map(function(d){return d.verfahren; }) );
    x.domain([0, 100 ]); //100 Mandate

    //create goups for verfahren and position them
    var verfahren = svg.selectAll(".verfahren")
      .data(data)
      .enter()
      .append("g")
      .attr("class", "g")
      .attr("transform", function(d){ return "translate(0," +y(d.verfahren)+")" });

    //create group for labels
    var label = svg.selectAll(".label")
      .data(data)
      .enter()
      .append("g")
      .attr("class", "label"); // und wie weiter? kenn mich nicht aus...

    //create bars
    verfahren.selectAll("rect")
      .data(function(d){ return d.mandate; })
      .enter()
      .append("rect")
      .classed('eins', function(d) { return d.verfahren === 'eins'; } )
      .classed('vergleich', function(d) { return d.verfahren !== 'eins'; } )
      .on("mouseover", tip.show)
      .on("mouseout", tip.hide)

    function reveal( what ) {
      verfahren.selectAll('rect.' + what)
      .transition().duration(2500)
      //.each("start", console.log("start"))
      //.each("end", function(d){ reveal(); })
      /*
      .transition().duration(function(d){
        switch(d.verfahren){
          case "eins":
            return 750
            break;
        case "n":
          return 4500
          break;
        case "n5":
          return 8000
          break;
        case "n75":
          return 10000
        }
        })
*/
      //set the height according to "verfahren"
      .attr("height", function(d){
          if(d.verfahren == "eins"){
            //return y.rangeBand()/2 ;
            return 10;
          }else{
            return 5;
          }
      })
      //set the x attribute to a fixed value according to party
      .attr("x", function(d){
        switch(d.name){
          case "SPO":
            return x(d.x0)
            break;
          case "OVP":
            return x(58)//should be the SPO max plus 1 - hardcoded instead
            break;
          case "Grune":
            return x(80) //max SPO+OVP:  62 plus 1
            break;
          case "FPO":
            return x(99) // max SPO+OVP+Grune + padding: 78
            break;
          case "LIF":
            return x(46)
        }
      })
      .attr("width", function(d) { return x(d.x1)-x(d.x0); })
      .style("fill", function(d){ return color[d.name] })
      .style("fill-opacity", "1")
      .attr( "transform", function(d){ //move 1st ar to top, so space is evenly distributed
          if(d.verfahren == "eins"){
            return "translate(0," + -5 + ")";
          }
        })
    }
    
    reveal( 'eins' );
    reveal( "vergleich" );

    /*
    button.on("click", function( ) {
      reveal( 'vergleich' );
    } );
    )*/

      //labels for mandate. there, but not visible yet.... after adding transitions gone completely
      verfahren.selectAll("rect")
        .append("text")
        .text(function(d){ return (d.x1-d.x0); })
        .style("fill", "black")
        .attr("x", function(d){ return d.x0 })
        .attr("dy", "1.5em")
        //.attr("text-anchor", "start");

      //add labels for verfahren - not there after adding transitions why?.
      verfahren.append("text")
      .text(function(d){
        switch(d.verfahren){
          case "eins":
            return "+1"
            break;
          case "n":
            return "+0"
            break;
          case "n5":
            return "+0,5"
            break;
          case "n75":
            return "+0,75"
        }
      })
      .style("fill", "black")
      .attr("x", -35)
      .attr("dy", "0.65em")
      .attr("text-anchor", "start");

    d3.select(".button").on("click", function( ) {
      reveal( 'vergleich' );
    } );

  });

}

